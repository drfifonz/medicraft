"""
This module provides the Trainer class for training models.
"""

__all__ = ["Trainer"]

from .trainer import Trainer
